//
//  FindFriendTableViewCell.m
//  studio9
//
//  Created by new on 29/03/16.
//  Copyright © 2016 Jipsaan. All rights reserved.
//

#import "FindFriendTableViewCell.h"

@implementation FindFriendTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
