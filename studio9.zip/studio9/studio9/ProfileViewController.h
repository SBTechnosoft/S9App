//
//  ProfileViewController.h
//  studio9
//
//  Created by new on 29/03/16.
//  Copyright © 2016 Jipsaan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileViewController : UIViewController<UICollectionViewDataSource,UICollectionViewDelegate>
@property (weak, nonatomic) IBOutlet UIButton *btnLogo;
@property (weak, nonatomic) IBOutlet UIButton *btnAdminMenu;
@property (weak, nonatomic) IBOutlet UICollectionView *ProfileCollection;
@end
