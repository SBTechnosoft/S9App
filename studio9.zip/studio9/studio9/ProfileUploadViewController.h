//
//  ProfileUploadViewController.h
//  studio9
//
//  Created by new on 29/03/16.
//  Copyright © 2016 Jipsaan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileUploadViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imgPic;
@property (weak, nonatomic) IBOutlet UILabel *lblLogo;

@end
