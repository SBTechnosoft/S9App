//
//  HomeTableViewCell.h
//  studio9
//
//  Created by new on 28/03/16.
//  Copyright © 2016 Jipsaan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeTableViewCell : UITableViewCell

@end
