//
//  LoginViewController.m
//  studio9
//
//  Created by new on 28/03/16.
//  Copyright © 2016 Jipsaan. All rights reserved.
//

#import "LoginViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [self setUI];
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField.tag == 10002) {
        textField.secureTextEntry = YES;
        textField.text = @"";
    }
    textField.text = @"";
    return YES;
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField.tag == 10001) {
        if ([textField.text length] == 0) {
            textField.text = @"User name";
        }
    }
    else if (textField.tag == 10002)
    {
        if ([textField.text length] == 0) {
            textField.secureTextEntry = NO;
            textField.text = @"Password";
        }
    }
}

#pragma mark - UserDefined Method
-(void)setUI
{
    _lblLogo.layer.borderColor = [UIColor whiteColor].CGColor;
    _lblLogo.layer.borderWidth = 7.0;
    _lblLogo.layer.cornerRadius = 3.0;
    _lblLogo.layer.masksToBounds = YES;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
