//
//  ViewController.m
//  studio9
//
//  Created by new on 28/03/16.
//  Copyright © 2016 Jipsaan. All rights reserved.
//

#import "ViewController.h"
#import "LoginNavController.h"
#import "RegNavController.h"

@interface ViewController ()
{
    UIStoryboard *storyboard;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [self setUI];
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - UIButtons Actions
- (IBAction)btnRegActn:(UIButton *)sender {
    RegNavController *RegIdNav = [storyboard instantiateViewControllerWithIdentifier:@"RegIdNav"];
    
}

- (IBAction)btnLoginActn:(UIButton *)sender {
}

#pragma mark - UserDefined Method
-(void)setUI
{
    storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    _lblLogo.layer.borderColor = [UIColor whiteColor].CGColor;
    _lblLogo.layer.borderWidth = 7.0;
    _lblLogo.layer.cornerRadius = 3.0;
    _lblLogo.layer.masksToBounds = YES;
}
@end
