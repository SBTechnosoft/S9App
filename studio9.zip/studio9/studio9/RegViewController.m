//
//  RegViewController.m
//  studio9
//
//  Created by new on 28/03/16.
//  Copyright © 2016 Jipsaan. All rights reserved.
//

#import "RegViewController.h"

@interface RegViewController ()

@end

@implementation RegViewController

- (void)viewDidLoad {
    [self setUI];
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UserDefined Method
-(void)setUI
{
    _lblLogo.layer.borderColor = [UIColor whiteColor].CGColor;
    _lblLogo.layer.borderWidth = 7.0;
    _lblLogo.layer.cornerRadius = 3.0;
    _lblLogo.layer.masksToBounds = YES;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
