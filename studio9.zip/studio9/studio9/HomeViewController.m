//
//  HomeViewController.m
//  studio9
//
//  Created by new on 28/03/16.
//  Copyright © 2016 Jipsaan. All rights reserved.
//

#import "HomeViewController.h"
#import "HomeTableViewCell.h"

@interface HomeViewController ()

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [self setUI];
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - UITableview Delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 12;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HomeTableViewCell *HomeCell;
    if (HomeCell == nil) {
        HomeCell = [tableView dequeueReusableCellWithIdentifier:@"HomeCell"];
    }
    return HomeCell;
}

#pragma mark - UIButton Actions Method
- (IBAction)btnLogoActn:(UIButton *)sender {
    if (!sender.selected)
    {
        [UIView animateWithDuration:0.5 animations:^{
            
             _vwMain.frame = CGRectMake(_vwDrawer.frame.origin.x, _vwMain.frame.origin.y, _vwMain.frame.size.width, _vwMain.frame.size.height);
            // vwMenu.frame = CGRectMake(0.0, 44.0, width-80, vwMenu.frame.size.height);
            _vwMain.alpha = 1.0;
            _vwMain.layer.zPosition=1;
            [self.view bringSubviewToFront:_vwMain];
        }];
    }
    else
    {
        [UIView animateWithDuration:0.5 animations:^{
            _vwMain.frame = CGRectMake(-(_vwDrawer.frame.origin.x + _vwDrawer.frame.size.width), _vwMain.frame.origin.y, _vwMain.frame.size.width, _vwMain.frame.size.height);
            _vwDrawer.alpha = 1.0;
        }];
    }
    
    
    sender.selected = !sender.selected;
}


#pragma mark - UserDefined Method
-(void)setUI
{
    _scrlDrawer.contentSize = CGSizeMake(_scrlDrawer.frame.size.width, 548);
    _vwMain.frame = CGRectMake(-(_vwDrawer.frame.origin.x + _vwDrawer.frame.size.width), _vwMain.frame.origin.y, _vwMain.frame.size.width, _vwMain.frame.size.height);
    
    _btnLogo.layer.borderColor = [UIColor whiteColor].CGColor;
    _btnLogo.layer.borderWidth = 2.0;
    _btnLogo.layer.cornerRadius = 3.0;
    _btnLogo.layer.masksToBounds = YES;
    
    _imgProPic.layer.borderColor = [UIColor colorWithRed:49.0/255.0 green:57.0/255.0 blue:93.0/255.0 alpha:1.0].CGColor;
    _imgProPic.layer.borderWidth = 3.0;
    _imgProPic.layer.masksToBounds = YES;
    _imgProPic.layer.cornerRadius = 72.0;
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
