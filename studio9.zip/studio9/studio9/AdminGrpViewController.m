//
//  AdminGrpViewController.m
//  studio9
//
//  Created by new on 28/03/16.
//  Copyright © 2016 Jipsaan. All rights reserved.
//

#import "AdminGrpViewController.h"

@interface AdminGrpViewController ()

@end

@implementation AdminGrpViewController

- (void)viewDidLoad {
    [self setUI];
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    textField.text = @"";
    return YES;
}
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField.tag == 10001) {
        if ([textField.text length] == 0) {
            textField.text = @"Add Caption";
        }
    }
    else if (textField.tag == 10002)
    {
        if ([textField.text length] == 0) {
            textField.text = @"Add / Remove People";
        }
    }
    else if (textField.tag == 10003)
    {
        if ([textField.text length] == 0) {
            textField.text = @"Edit Post";
        }
    }
    else if (textField.tag == 10004)
    {
        if ([textField.text length] == 0) {
            textField.text = @"Delete Group";
        }
    }
}



#pragma mark - UIButton Actions Method
- (IBAction)btnLogoActn:(UIButton *)sender {
    if (!sender.selected)
    {
        [UIView animateWithDuration:0.5 animations:^{
            
            _vwMain.frame = CGRectMake(_vwDrawer.frame.origin.x, _vwMain.frame.origin.y, _vwMain.frame.size.width, _vwMain.frame.size.height);
            // vwMenu.frame = CGRectMake(0.0, 44.0, width-80, vwMenu.frame.size.height);
            _vwMain.alpha = 1.0;
            _vwMain.layer.zPosition=1;
            [self.view bringSubviewToFront:_vwMain];
        }];
    }
    else
    {
        [UIView animateWithDuration:0.5 animations:^{
            _vwMain.frame = CGRectMake(-(_vwDrawer.frame.origin.x + _vwDrawer.frame.size.width), _vwMain.frame.origin.y, _vwMain.frame.size.width, _vwMain.frame.size.height);
            _vwDrawer.alpha = 1.0;
        }];
    }
    
    
    sender.selected = !sender.selected;
}

#pragma mark - UserDefined Method
-(void)setUI
{
    _vwMain.frame = CGRectMake(-(_vwDrawer.frame.origin.x + _vwDrawer.frame.size.width), _vwMain.frame.origin.y, _vwMain.frame.size.width, _vwMain.frame.size.height);
    
    _btnLogo.layer.borderColor = [UIColor whiteColor].CGColor;
    _btnLogo.layer.borderWidth = 2.0;
    _btnLogo.layer.cornerRadius = 3.0;
    _btnLogo.layer.masksToBounds = YES;
    
//    _btnAdminMenu.layer.borderColor = [UIColor whiteColor].CGColor;
//    _btnAdminMenu.layer.borderWidth = 1.0;

    _imgGrpPic.layer.borderColor = [UIColor colorWithRed:49.0/255.0 green:57.0/255.0 blue:93.0/255.0 alpha:1.0].CGColor;
    _imgGrpPic.layer.borderWidth = 3.0;
    _imgGrpPic.layer.masksToBounds = YES;
    CGPoint saveCenter = _imgGrpPic.center;
    CGRect newFrame = CGRectMake(_imgGrpPic.frame.origin.x, _imgGrpPic.frame.origin.y, 140.0, 140.0);
    _imgGrpPic.frame = newFrame;
    _imgGrpPic.layer.masksToBounds = YES;
    _imgGrpPic.layer.cornerRadius = 140.0 / 2.0;
    _imgGrpPic.center = saveCenter;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
