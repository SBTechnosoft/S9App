//
//  UploadPicViewController.m
//  studio9
//
//  Created by new on 29/03/16.
//  Copyright © 2016 Jipsaan. All rights reserved.
//

#import "UploadPicViewController.h"

@interface UploadPicViewController ()

@end

@implementation UploadPicViewController

- (void)viewDidLoad {
    [self setUI];
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UIButton Actions
- (IBAction)btnBackActn:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UserDefined Method
-(void)setUI
{
    _vwMain.frame = CGRectMake(-(_vwDrawer.frame.origin.x + _vwDrawer.frame.size.width), _vwMain.frame.origin.y, _vwMain.frame.size.width, _vwMain.frame.size.height);
    
    _btnLogo.layer.borderColor = [UIColor whiteColor].CGColor;
    _btnLogo.layer.borderWidth = 2.0;
    _btnLogo.layer.cornerRadius = 3.0;
    _btnLogo.layer.masksToBounds = YES;
    
    _btnAdminMenu.layer.borderColor = [UIColor whiteColor].CGColor;
    _btnAdminMenu.layer.borderWidth = 1.0;
    
    _imgPic.layer.borderColor = [UIColor colorWithRed:49.0/255.0 green:57.0/255.0 blue:93.0/255.0 alpha:1.0].CGColor;
    _imgPic.layer.borderWidth = 3.0;
//    _imgPic.layer.masksToBounds = YES;
//    _imgPic.layer.cornerRadius = 72.0;
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
