//
//  UploadPicViewController.m
//  studio9
//
//  Created by new on 29/03/16.
//  Copyright © 2016 Jipsaan. All rights reserved.
//

#import "UploadPicViewController.h"

@interface UploadPicViewController ()
{
    UIImagePickerController *imgPicker;
}
@end

@implementation UploadPicViewController

- (void)viewDidLoad {
    [self setUI];
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UIButton Actions
- (IBAction)btnBackActn:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnUploadPicActn:(UIButton *)sender
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Camera",@"Gallery", nil];
    
    [actionSheet showInView:self.view];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 0:
            [self takeNewPhotoFromCamera];
            break;
        case 1:
            [self choosePhotoFromExistingImages];
        default:
            break;
    }
    
}

#pragma mark - UserDefined Method
-(void)setUI
{
    _vwMain.frame = CGRectMake(-(_vwDrawer.frame.origin.x + _vwDrawer.frame.size.width), _vwMain.frame.origin.y, _vwMain.frame.size.width, _vwMain.frame.size.height);
    
    _btnLogo.layer.borderColor = [UIColor whiteColor].CGColor;
    _btnLogo.layer.borderWidth = 2.0;
    _btnLogo.layer.cornerRadius = 3.0;
    _btnLogo.layer.masksToBounds = YES;
    
//    _btnAdminMenu.layer.borderColor = [UIColor whiteColor].CGColor;
//    _btnAdminMenu.layer.borderWidth = 1.0;
    
    _btnPic.layer.borderColor = [UIColor colorWithRed:49.0/255.0 green:57.0/255.0 blue:93.0/255.0 alpha:1.0].CGColor;
    _btnPic.layer.borderWidth = 3.0;
    _btnPic.layer.masksToBounds = YES;
    _btnPic.layer.cornerRadius = 20.0;
    
}

-(void)takeNewPhotoFromCamera
{
    imgPicker = [[UIImagePickerController alloc] init];
    imgPicker.allowsEditing = YES;
    imgPicker.delegate = self;
    imgPicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    [self presentViewController:imgPicker animated:YES completion:nil];
}

-(void)choosePhotoFromExistingImages
{
    if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeSavedPhotosAlbum])
    {
    imgPicker = [[UIImagePickerController alloc] init];
        imgPicker.allowsEditing = YES;
        imgPicker.delegate = self;
    imgPicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [self presentViewController:imgPicker animated:YES completion:nil];
    }
}


#pragma mark ===== UIImagePickerController Delegate =====

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [self.navigationController dismissViewControllerAnimated:NO completion: nil];
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
    UIImage *img = [info valueForKey:UIImagePickerControllerEditedImage];
//    [_btnPic setImage:img forState:UIControlStateNormal];
    [_btnPic setBackgroundImage:img forState:UIControlStateNormal];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
