//
//  UploadPicViewController.h
//  studio9
//
//  Created by new on 29/03/16.
//  Copyright © 2016 Jipsaan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UploadPicViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imgPic;

@property (weak, nonatomic) IBOutlet UIView *vwDrawer;

@property (weak, nonatomic) IBOutlet UIButton *btnLogo;
@property (weak, nonatomic) IBOutlet UIView *vwMain;
@property (weak, nonatomic) IBOutlet UIButton *btnAdminMenu;

@end
