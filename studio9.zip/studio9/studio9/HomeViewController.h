//
//  HomeViewController.h
//  studio9
//
//  Created by new on 28/03/16.
//  Copyright © 2016 Jipsaan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>
//Drawer
@property (weak, nonatomic) IBOutlet UIImageView *imgProPic;
@property (weak, nonatomic) IBOutlet UIView *vwDrawer;
@property (weak, nonatomic) IBOutlet UIScrollView *scrlDrawer;

//Home Page
@property (weak, nonatomic) IBOutlet UIButton *btnLogo;
@property (weak, nonatomic) IBOutlet UIView *vwMain;
@property (weak, nonatomic) IBOutlet UIImageView *imgTopProPic;

@end
